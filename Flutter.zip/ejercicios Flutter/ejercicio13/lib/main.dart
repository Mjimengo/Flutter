import 'package:flutter/material.dart';
import 'dart:math';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  String _username = "";
  String _password = "";
  int _randomNumber = 0;
  int _userNumber = 0;

  @override
  void initState() {
    super.initState();
    _randomNumber = new Random().nextInt(10);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 245, 204, 252),
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                TextFormField(
                  decoration: InputDecoration(
                      hintText: 'Nombre de usuario',
                      labelText: 'Introduce tu nombre de usuario',
                      labelStyle: TextStyle(color: Colors.deepPurple),
                      hintStyle:
                          TextStyle(color: Color.fromARGB(255, 172, 136, 234))),
                  validator: (value) {
                    if (!RegExp(r'^[a-zA-Z0-9]+$').hasMatch(value!)) {
                      return 'Por favor, introduzca un nombre de usuario válido.';
                    }
                    _username = value;
                    return null;
                  },
                  style: TextStyle(color: Colors.deepPurple),
                ),
                SizedBox(
                  height: 20.0,
                ),
                TextFormField(
                  decoration: InputDecoration(
                      hintText: 'Contraseña',
                      labelText: 'Introduce tu contraseña',
                      labelStyle: TextStyle(color: Colors.deepPurple),
                      hintStyle:
                          TextStyle(color: Color.fromARGB(255, 172, 136, 234))),
                  validator: (value) {
                    if (!RegExp(
                            r'^(?=.[A-Za-z])(?=.\d)(?=.[@$!%#?&])[A-Za-z\d@$!%*#?&]{5,}$')
                        .hasMatch(value!)) {
                      return 'La contraseña debe tener al menos 5 caracteres' +
                          '\n' +
                          'y debe incluir letras, números y caracteres especiales';
                    }
                    _password = value;
                    return null;
                  },
                  obscureText: true,
                  style: TextStyle(color: Colors.deepPurple),
                ),
                SizedBox(
                  height: 20.0,
                ),
                TextFormField(
                  decoration: InputDecoration(
                      hintText: 'Introduce un número',
                      labelText: 'Introduce un número',
                      labelStyle: TextStyle(color: Colors.deepPurple),
                      hintStyle:
                          TextStyle(color: Color.fromARGB(255, 172, 136, 234))),
                  validator: (value) {
                    if (!RegExp(r'^[0-9]+$').hasMatch(value!)) {
                      return 'Por favor, introduzca un número válido.';
                    }
                    _userNumber = int.parse(value);
                    if (_userNumber > _randomNumber) {
                      return 'El número introducido es mayor';
                    } else if (_userNumber < _randomNumber) {
                      return 'El número introducido es menor';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.deepPurple),
                ),
                SizedBox(
                  height: 20.0,
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      if (_username != 'username' ||
                          _password != 'password' ||
                          _userNumber != _randomNumber) {
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: Text("Error"),
                                content: Text(
                                    "Los datos introducidos son inválidos"),
                                actions: <Widget>[
                                  FloatingActionButton(
                                    child: Text("Ok",
                                        style: TextStyle(color: Colors.white)),
                                    backgroundColor: Colors.deepPurple,
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                  )
                                ],
                              );
                            });
                      } else {}
                    }
                  },
                  child: Text("Enviar", style: TextStyle(color: Colors.white)),
                )
              ],
            )),
      ),
    );
  }
}
