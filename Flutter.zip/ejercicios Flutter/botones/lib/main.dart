import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Botones',
      home: Scaffold(
          appBar: AppBar(
            title: const Center(
              child: Text('Práctica Botones'),
            ),
          ),
          body: GridView.count(
            primary: false,
            padding: const EdgeInsets.all(20),
            crossAxisSpacing: 4,
            mainAxisSpacing: 4,
            crossAxisCount: 2,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(8),
                color: Color.fromARGB(255, 139, 202, 110),
                child: Align(
                  child: ElevatedButton(
                    child: Text('Elevated Button'),
                    onPressed: () {},
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: Color.fromARGB(255, 139, 202, 110),
                child: Align(
                  child: ElevatedButton.icon(
                    label: const Text('Elevated Button'),
                    icon: const Icon(Icons.ac_unit_rounded),
                    onPressed: () {},
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: Color.fromARGB(255, 139, 202, 110),
                child: Align(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Color.fromARGB(255, 56, 29, 125),
                      onPrimary: Colors.white,
                      onSurface: Color.fromARGB(255, 152, 167, 255),
                    ),
                    onPressed: () {},
                    child: const Text('Elevated Button'),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: Color.fromARGB(255, 139, 202, 110),
                child: Align(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Color.fromARGB(255, 22, 150, 0),
                      onPrimary: Colors.white,
                      textStyle: const TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontStyle: FontStyle.italic),
                    ),
                    onPressed: () {},
                    child: const Text('Elevated Button'),
                  ),
                ),
              ),
              Container(
                  padding: const EdgeInsets.all(8),
                  color: Color.fromARGB(255, 139, 202, 110),
                  child: Align(
                    child: ElevatedButton(
                      child: const Text('Elevated Button'),
                      style: ElevatedButton.styleFrom(
                        primary: Color.fromARGB(255, 243, 208, 33),
                        onPrimary: Colors.white,
                        shadowColor: Color.fromARGB(255, 120, 39, 10),
                        elevation: 15,
                      ),
                      onPressed: () {},
                    ),
                  )),
              Container(
                  padding: const EdgeInsets.all(8),
                  color: Color.fromARGB(255, 139, 202, 110),
                  child: Align(
                      child: OutlinedButton(
                    child: const Text('Outlined Button'),
                    onPressed: () {},
                  ))),
            ],
          )),
    );
  }
}
