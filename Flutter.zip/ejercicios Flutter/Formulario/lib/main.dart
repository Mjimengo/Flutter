import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  String value = "";
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.deepPurple,
        body: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Form(
            child: Column(
              children: <Widget>[
                TextFormField(
                  decoration: InputDecoration(
                      hintText: 'Nombre de usuario',
                      labelText: 'Introduce tu nombre de usuario',
                      labelStyle: TextStyle(color: Colors.white),
                      hintStyle: TextStyle(color: Colors.white)),
                  validator: (value) {
                    if (!RegExp(r'^[a-zA-Z0-9]+$').hasMatch(value!)) {
                      return 'Por favor, introduzca un nombre de usuario válido.';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                ),
                SizedBox(
                  height: 20.0,
                ),
                TextFormField(
                  decoration: InputDecoration(
                      hintText: 'Contraseña',
                      labelText: 'Introduce tu contraseña',
                      labelStyle: TextStyle(color: Colors.white),
                      hintStyle: TextStyle(color: Colors.white)),
                  validator: (value) {
                    if (!RegExp(
                            r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{5,}$')
                        .hasMatch(value!)) {
                      return 'La contraseña debe tener al menos 5 caracteres y debe incluir letras, números y caracteres especiales';
                    }
                    return null;
                  },
                  obscureText: true,
                  style: TextStyle(color: Colors.white),
                ),
                SizedBox(
                  height: 20.0,
                ),
                ElevatedButton(
                  onPressed: () {},
                  child: Text('Iniciar sesión',
                      style: TextStyle(color: Colors.white)),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
