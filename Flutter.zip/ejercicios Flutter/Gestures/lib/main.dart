import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gestures',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: AnimateApp(),
    );
  }
}

class AnimateApp extends StatefulWidget {
  const AnimateApp({super.key});

  @override
  State<StatefulWidget> createState() {
    return _AnimateAppState();
  }
}

class _AnimateAppState extends State<AnimateApp>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> animation;
  late CurvedAnimation curve;
  double size = 200.0;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000));
    curve = CurvedAnimation(parent: controller, curve: Curves.easeIn);

    animation = Tween(begin: 1.0, end: 2.0).animate(controller)
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Aplicacion',
        theme: ThemeData(primaryColor: Colors.teal),
        home: Scaffold(
            appBar: AppBar(
              title: const Text('Aplicacion'),
            ),
            body: Center(
              child: GestureDetector(
                child: ScaleTransition(
                    scale: animation,
                    child: Image.asset(
                      "assets/images/perro.jpg",
                      width: size,
                      height: size,
                    )),
                onDoubleTap: () {
                  controller.reset();
                  animation = Tween(begin: 2.0, end: 1.0).animate(controller)
                    ..addListener(() {
                      setState(() {});
                    });
                  controller.forward();
                },
                onTap: () {
                  controller.reset();
                  animation = Tween(begin: 1.0, end: 2.0).animate(controller)
                    ..addListener(() {
                      setState(() {});
                    });
                  controller.forward();
                },
              ),
            )));
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
}
